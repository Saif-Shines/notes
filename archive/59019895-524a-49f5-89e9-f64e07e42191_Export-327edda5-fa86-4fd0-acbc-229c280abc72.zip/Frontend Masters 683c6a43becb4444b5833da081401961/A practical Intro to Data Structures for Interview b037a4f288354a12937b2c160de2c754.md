# A practical Intro to Data Structures for Interviews

[Introduction to Data Structures for Interviews](https://slides.com/bgando/intro-to-ds-1)