# Functional Programming first steps

[An introduction to functional programming](https://codewords.recurse.com/issues/one/an-introduction-to-functional-programming)

### Course content

[What is functional programming?](https://observablehq.com/@anjana/what-is-functional-programming?collection=@anjana/functional-javascript-first-steps)

[Object Oriented Programming is not what I thought - Talk by Anjana Vakil](https://www.youtube.com/watch?v=TbP2B1ijWr8)

> Idea of functional programming expands on one core idea of pure functions. Eventually all other concepts will make sense
> 

# Staying out of the loop with recursion