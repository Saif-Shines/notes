# JS: The New Hardparts

[](https://static.frontendmasters.com/resources/2018-05-23-javascript-new-hard-parts/new-hard-parts-slides.pdf)

[new-hard-parts-slides.pdf](JS%20The%20New%20Hardparts%20ccf09e6763a14f598d7f7e05868425a7/new-hard-parts-slides.pdf)