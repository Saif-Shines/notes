# Introduction to Product Management

# Introduction

[Complete Intro to Product Management](https://pm.holt.courses/)

Brain basically tells his bias coming from technical and developer tools backgrounds. He wants the learners to be aware of it and ensure that there are many many other ways to become a good PM and this doesn’t have to the only one.