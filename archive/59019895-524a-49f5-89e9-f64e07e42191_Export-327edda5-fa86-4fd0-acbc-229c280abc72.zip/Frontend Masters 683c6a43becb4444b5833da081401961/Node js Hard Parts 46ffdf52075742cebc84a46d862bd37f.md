# Node.js Hard Parts

[https://static.frontendmasters.com/resources/2019-04-24-servers-node-js/Hard-Parts-Servers-Node.pdf](https://static.frontendmasters.com/resources/2019-04-24-servers-node-js/Hard-Parts-Servers-Node.pdf)

[https://gist.github.com/i-python-com/015011f54f918a1942b6fce70ced87fb](https://gist.github.com/i-python-com/015011f54f918a1942b6fce70ced87fb)

### Notes