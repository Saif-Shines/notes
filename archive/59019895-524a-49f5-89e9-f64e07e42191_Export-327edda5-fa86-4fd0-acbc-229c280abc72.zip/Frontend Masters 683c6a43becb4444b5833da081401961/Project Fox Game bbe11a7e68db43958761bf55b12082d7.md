# Project Fox Game

[Project Fox Game](http://bit.ly/fox-game)

> Always organise your code to optimise it for deletability
>