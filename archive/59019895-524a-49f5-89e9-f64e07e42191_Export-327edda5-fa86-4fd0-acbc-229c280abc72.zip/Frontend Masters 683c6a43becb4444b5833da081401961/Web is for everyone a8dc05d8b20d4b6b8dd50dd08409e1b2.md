# Web is for everyone

[WebAIM: Web Accessibility In Mind](https://webaim.org/)

[jkup/shortcut](https://github.com/jkup/shortcut)

[jkup/learn-a11y](https://github.com/jkup/learn-a11y)