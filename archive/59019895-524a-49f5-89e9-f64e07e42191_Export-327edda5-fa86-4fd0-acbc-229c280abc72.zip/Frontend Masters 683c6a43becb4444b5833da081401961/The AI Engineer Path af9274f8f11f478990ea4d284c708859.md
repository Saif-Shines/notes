# The AI Engineer Path

# Introduction

An AI engineer is not the one who will improve the models or handle the options around it. They are AI researchers or ML engineers. We will use those model to build application that are not possible before!

So let’s get started!

# Stock Broker App

![Untitled](The%20AI%20Engineer%20Path%20af9274f8f11f478990ea4d284c708859/Untitled.png)

We will build a Stock Broker app, where users can select 2-3 tickers, and get a prediction or suggestion in the form of a report!