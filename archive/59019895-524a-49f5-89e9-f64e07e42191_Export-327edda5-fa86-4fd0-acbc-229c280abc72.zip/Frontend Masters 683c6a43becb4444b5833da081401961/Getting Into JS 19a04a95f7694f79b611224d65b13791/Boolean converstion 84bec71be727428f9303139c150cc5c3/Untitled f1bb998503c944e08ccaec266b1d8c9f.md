# ""

Truthy: Everything else returns true