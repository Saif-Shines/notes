# The VIM Fundamentals

[Vim Fundamentals](https://theprimeagen.github.io/vim-fundamentals/)