# CSS Gradient

Comments: To understand CSS Gradients