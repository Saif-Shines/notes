# Grid Generator, Learn Grid Specs

Comments: To understand Grids