# changelog.com

Comments: Conversations with the hackers, leaders & innovators of software development