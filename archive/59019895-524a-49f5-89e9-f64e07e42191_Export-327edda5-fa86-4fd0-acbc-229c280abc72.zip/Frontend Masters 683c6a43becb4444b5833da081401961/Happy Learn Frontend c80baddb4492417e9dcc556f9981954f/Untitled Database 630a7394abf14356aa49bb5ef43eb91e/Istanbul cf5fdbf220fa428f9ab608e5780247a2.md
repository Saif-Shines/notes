# Istanbul

Comments: Test coverage toolHelps understanding how code coverage instrumentation works under the hood by parsing the source JS with ESPrima, adding instrumentation, and converting that back to instrumented code using ESCodegen