# Typescript

Comments: JS with type-checking